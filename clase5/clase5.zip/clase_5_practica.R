## 1. Importe las librerías ggplot y tidyverse. 

## 2. Importe la base PUFEAF. 

## 3. ¿En qué provincia hubieron más casos de uso de armas de fuego? 

## 4. En esta provincia, ¿qué fuerza las usó más veces?

## 5. Grafique cómo evolucionaron a lo largo del tiempo los casos según la situación de servicio (Situacion_de_Servicio).

## 6. Grafique la evolución temporal de la cantidad de personas heridas para cada provincia. Realice lo mismo para la cantidad de fallecidos. 