### 1. Instalen los paquetes haven y openxlsx

### 2. Abran el .RProj de la carpeta 

### 3. Importen la base de homicidios dolosos que está en la carpeta "data" detallando la ruta desde el punto de partida del proyecto:
### a. En formato .dta
### b. En formato .xlsx

### 4. ¿Cómo es la distribución de frecuencias del sexo de las víctimas? ¿Y de la identidad de género? 

### 5. Creen un objeto que contenga las primeras 500 filas de la base de datos. 

### 6. Cree un objeto donde estén únicamente aquellas filas que provincia == "BUENOS AIRES"

### 7. Guardar esta última base de datos en formato .RDS

### 8. Instalen los paquetes tidyverse, stringr y lubridate.