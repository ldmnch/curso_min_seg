#1. Cargue la base de datos de delitos en CABA que está en la carpeta data. 
# Ojo: está en formato .rda. Recuerden (clase 2) que para importar este tipo de archivos usamos la función load(). 

#2. Realice un gráfico interactivo mostrando dónde sucedieron homicidios dolosos en 2020. 

#3. Realice un gráfico interactivo mostrando cómo se distribuyen los distintos tipos de delitos entre los barrios.

# 4. Realice un gráfico interactivo mostrando cómo evoluciona la cantidad de crímenes por barrio a lo largo del año.

