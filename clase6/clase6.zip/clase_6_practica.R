# 1. Importe los paquetes ggplot, tidyverse y sf
# 2. Importe la base de homicidios dolosos. 
# 3. Grafique en un mapa la cantidad de víctimas de homicidio/cantidad de habitantes para 
# los años 2017-2020 en la región del NOA (Tucumán, Jujuy, Salta, Catamarca, Santiago del Estero, La Rioja). 
